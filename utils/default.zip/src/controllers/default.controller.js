export default (request, response) => {
    response.send({
        message: 'Sample controller response'
    })
}