import express from 'express'
import bodyParser from 'body-parser'
import cors from 'cors'

import appRoutes from './routes'

const app = express()
const port = process.env.PORT || 9000

app.use(bodyParser.json())
app.use(cors())

app.get('/', (request, response) => {
    response.send("Server up & running! Yayyy!!")
})

appRoutes(app)

app.listen(port, () => {
    console.log(`Listening to port ${port}`)
})