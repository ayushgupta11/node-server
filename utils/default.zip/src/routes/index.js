import defaultApi from '../controllers/default.controller'

export default (app) => {
    app.get('/test', defaultApi)
    return app
}